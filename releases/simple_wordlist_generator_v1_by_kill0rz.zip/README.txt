Simple Wordlist Generator v1 by kill0rz - visit http://kill0rz.com/

+++ Beschreibung +++

Dieses Script generiert eine beliebig gro�e Wordlist nach den Vorgaben.
Diese werden im Ordner tmp/ zwischengespeichert und bei jedem Seitenaufruf wieder entfernt (Verhindern einer zugem�llten Festplatte).
Demnach ist ein Multiuserbetrieb nicht m�glich.

+++ Installation +++

Lade den ordner tmp/ und die index.php auf deinen Server.
Gib dem Ordner tmp/ Schreibrechte.

+++ Anwendung +++

Einfach die index.php aufrufen und deine Vorgaben anhaken. In das Textfeld unten kannst du zus�tzlich noch eigene Bausteine hinzuf�gen.

+++ Lizenz +++

Dieses Script wurde unter kill0rz Unilicence v1 ver�ffentlicht. Diese liegt bei.


Viel Spa� bei der Anwendung,
kill0rz

Stand 26.01.2015